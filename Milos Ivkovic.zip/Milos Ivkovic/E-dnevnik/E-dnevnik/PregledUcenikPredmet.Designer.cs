﻿namespace E_dnevnik
{
    partial class PregledUcenikPredmet
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnPrikazi = new System.Windows.Forms.Button();
            this.lbOcene = new System.Windows.Forms.ListBox();
            this.cbPredmet = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cbUcenik = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dnevnikDataSet = new E_dnevnik.DnevnikDataSet();
            this.ucenikBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ucenikTableAdapter = new E_dnevnik.DnevnikDataSetTableAdapters.UcenikTableAdapter();
            this.predmetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.predmetTableAdapter = new E_dnevnik.DnevnikDataSetTableAdapters.PredmetTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.dnevnikDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ucenikBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.predmetBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // btnPrikazi
            // 
            this.btnPrikazi.Location = new System.Drawing.Point(294, 111);
            this.btnPrikazi.Name = "btnPrikazi";
            this.btnPrikazi.Size = new System.Drawing.Size(75, 33);
            this.btnPrikazi.TabIndex = 11;
            this.btnPrikazi.Text = "Prikazi";
            this.btnPrikazi.UseVisualStyleBackColor = true;
            this.btnPrikazi.Click += new System.EventHandler(this.btnPrikazi_Click);
            // 
            // lbOcene
            // 
            this.lbOcene.FormattingEnabled = true;
            this.lbOcene.ItemHeight = 16;
            this.lbOcene.Location = new System.Drawing.Point(26, 179);
            this.lbOcene.Name = "lbOcene";
            this.lbOcene.Size = new System.Drawing.Size(322, 244);
            this.lbOcene.TabIndex = 10;
            // 
            // cbPredmet
            // 
            this.cbPredmet.DataSource = this.predmetBindingSource;
            this.cbPredmet.DisplayMember = "naziv";
            this.cbPredmet.FormattingEnabled = true;
            this.cbPredmet.Location = new System.Drawing.Point(456, 45);
            this.cbPredmet.Name = "cbPredmet";
            this.cbPredmet.Size = new System.Drawing.Size(191, 24);
            this.cbPredmet.TabIndex = 9;
            this.cbPredmet.ValueMember = "IDPredmet";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(382, 48);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 17);
            this.label2.TabIndex = 8;
            this.label2.Text = "Predmet";
            // 
            // cbUcenik
            // 
            this.cbUcenik.DataSource = this.ucenikBindingSource;
            this.cbUcenik.DisplayMember = "imePrezime";
            this.cbUcenik.FormattingEnabled = true;
            this.cbUcenik.Location = new System.Drawing.Point(108, 45);
            this.cbUcenik.Name = "cbUcenik";
            this.cbUcenik.Size = new System.Drawing.Size(191, 24);
            this.cbUcenik.TabIndex = 7;
            this.cbUcenik.ValueMember = "sifraUcenik";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(34, 48);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 17);
            this.label1.TabIndex = 6;
            this.label1.Text = "Ucenik";
            // 
            // dnevnikDataSet
            // 
            this.dnevnikDataSet.DataSetName = "DnevnikDataSet";
            this.dnevnikDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // ucenikBindingSource
            // 
            this.ucenikBindingSource.DataMember = "Ucenik";
            this.ucenikBindingSource.DataSource = this.dnevnikDataSet;
            // 
            // ucenikTableAdapter
            // 
            this.ucenikTableAdapter.ClearBeforeFill = true;
            // 
            // predmetBindingSource
            // 
            this.predmetBindingSource.DataMember = "Predmet";
            this.predmetBindingSource.DataSource = this.dnevnikDataSet;
            // 
            // predmetTableAdapter
            // 
            this.predmetTableAdapter.ClearBeforeFill = true;
            // 
            // PregledUcenikPredmet
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnPrikazi);
            this.Controls.Add(this.lbOcene);
            this.Controls.Add(this.cbPredmet);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cbUcenik);
            this.Controls.Add(this.label1);
            this.Name = "PregledUcenikPredmet";
            this.Text = "PregledUcenikPredmet";
            this.Load += new System.EventHandler(this.PregledUcenikPredmet_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dnevnikDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ucenikBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.predmetBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnPrikazi;
        private System.Windows.Forms.ListBox lbOcene;
        private System.Windows.Forms.ComboBox cbPredmet;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cbUcenik;
        private System.Windows.Forms.Label label1;
        private DnevnikDataSet dnevnikDataSet;
        private System.Windows.Forms.BindingSource ucenikBindingSource;
        private DnevnikDataSetTableAdapters.UcenikTableAdapter ucenikTableAdapter;
        private System.Windows.Forms.BindingSource predmetBindingSource;
        private DnevnikDataSetTableAdapters.PredmetTableAdapter predmetTableAdapter;
    }
}