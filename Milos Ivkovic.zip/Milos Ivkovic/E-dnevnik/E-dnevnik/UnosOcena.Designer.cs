﻿namespace E_dnevnik
{
    partial class UnosOcena
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.cbPredmet = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cbNastavnik = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dnevnikDataSet = new E_dnevnik.DnevnikDataSet();
            this.nastavnikBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.nastavnikTableAdapter = new E_dnevnik.DnevnikDataSetTableAdapters.NastavnikTableAdapter();
            this.cbUcenik = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.ucenikBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ucenikTableAdapter = new E_dnevnik.DnevnikDataSetTableAdapters.UcenikTableAdapter();
            this.label4 = new System.Windows.Forms.Label();
            this.cbOcena = new System.Windows.Forms.ComboBox();
            this.btnPotvrdi = new System.Windows.Forms.Button();
            this.lbOcene = new System.Windows.Forms.ListBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tbDatum = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dnevnikDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nastavnikBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ucenikBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // cbPredmet
            // 
            this.cbPredmet.DisplayMember = "naziv";
            this.cbPredmet.FormattingEnabled = true;
            this.cbPredmet.Location = new System.Drawing.Point(456, 73);
            this.cbPredmet.Name = "cbPredmet";
            this.cbPredmet.Size = new System.Drawing.Size(191, 24);
            this.cbPredmet.TabIndex = 7;
            this.cbPredmet.ValueMember = "IDPredmet";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(382, 76);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 17);
            this.label2.TabIndex = 6;
            this.label2.Text = "Predmet";
            // 
            // cbNastavnik
            // 
            this.cbNastavnik.DataSource = this.nastavnikBindingSource;
            this.cbNastavnik.DisplayMember = "imePrezime";
            this.cbNastavnik.FormattingEnabled = true;
            this.cbNastavnik.Location = new System.Drawing.Point(108, 73);
            this.cbNastavnik.Name = "cbNastavnik";
            this.cbNastavnik.Size = new System.Drawing.Size(191, 24);
            this.cbNastavnik.TabIndex = 5;
            this.cbNastavnik.ValueMember = "sifraNastavnika";
            this.cbNastavnik.SelectedIndexChanged += new System.EventHandler(this.cbNastavnik_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(34, 76);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 17);
            this.label1.TabIndex = 4;
            this.label1.Text = "Nastavnik";
            // 
            // dnevnikDataSet
            // 
            this.dnevnikDataSet.DataSetName = "DnevnikDataSet";
            this.dnevnikDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // nastavnikBindingSource
            // 
            this.nastavnikBindingSource.DataMember = "Nastavnik";
            this.nastavnikBindingSource.DataSource = this.dnevnikDataSet;
            // 
            // nastavnikTableAdapter
            // 
            this.nastavnikTableAdapter.ClearBeforeFill = true;
            // 
            // cbUcenik
            // 
            this.cbUcenik.DataSource = this.ucenikBindingSource;
            this.cbUcenik.DisplayMember = "imePrezime";
            this.cbUcenik.FormattingEnabled = true;
            this.cbUcenik.Location = new System.Drawing.Point(108, 175);
            this.cbUcenik.Name = "cbUcenik";
            this.cbUcenik.Size = new System.Drawing.Size(191, 24);
            this.cbUcenik.TabIndex = 9;
            this.cbUcenik.ValueMember = "sifraUcenik";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(34, 178);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(51, 17);
            this.label3.TabIndex = 8;
            this.label3.Text = "Ucenik";
            // 
            // ucenikBindingSource
            // 
            this.ucenikBindingSource.DataMember = "Ucenik";
            this.ucenikBindingSource.DataSource = this.dnevnikDataSet;
            // 
            // ucenikTableAdapter
            // 
            this.ucenikTableAdapter.ClearBeforeFill = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(385, 177);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(50, 17);
            this.label4.TabIndex = 10;
            this.label4.Text = "Ocena";
            // 
            // cbOcena
            // 
            this.cbOcena.FormattingEnabled = true;
            this.cbOcena.Items.AddRange(new object[] {
            "5",
            "4",
            "3",
            "2",
            "1"});
            this.cbOcena.Location = new System.Drawing.Point(456, 169);
            this.cbOcena.Name = "cbOcena";
            this.cbOcena.Size = new System.Drawing.Size(78, 24);
            this.cbOcena.TabIndex = 11;
            // 
            // btnPotvrdi
            // 
            this.btnPotvrdi.Location = new System.Drawing.Point(306, 225);
            this.btnPotvrdi.Name = "btnPotvrdi";
            this.btnPotvrdi.Size = new System.Drawing.Size(75, 30);
            this.btnPotvrdi.TabIndex = 12;
            this.btnPotvrdi.Text = "Potvrdi";
            this.btnPotvrdi.UseVisualStyleBackColor = true;
            this.btnPotvrdi.Click += new System.EventHandler(this.btnPotvrdi_Click);
            // 
            // lbOcene
            // 
            this.lbOcene.FormattingEnabled = true;
            this.lbOcene.ItemHeight = 16;
            this.lbOcene.Location = new System.Drawing.Point(37, 283);
            this.lbOcene.Name = "lbOcene";
            this.lbOcene.Size = new System.Drawing.Size(322, 116);
            this.lbOcene.TabIndex = 13;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(37, 225);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(49, 17);
            this.label5.TabIndex = 14;
            this.label5.Text = "Datum";
            // 
            // tbDatum
            // 
            this.tbDatum.Location = new System.Drawing.Point(108, 225);
            this.tbDatum.Name = "tbDatum";
            this.tbDatum.Size = new System.Drawing.Size(104, 22);
            this.tbDatum.TabIndex = 15;
            // 
            // UnosOcena
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(809, 489);
            this.Controls.Add(this.tbDatum);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lbOcene);
            this.Controls.Add(this.btnPotvrdi);
            this.Controls.Add(this.cbOcena);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.cbUcenik);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cbPredmet);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cbNastavnik);
            this.Controls.Add(this.label1);
            this.Name = "UnosOcena";
            this.Text = "UnosOcena";
            this.Load += new System.EventHandler(this.UnosOcena_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dnevnikDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nastavnikBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ucenikBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cbPredmet;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cbNastavnik;
        private System.Windows.Forms.Label label1;
        private DnevnikDataSet dnevnikDataSet;
        private System.Windows.Forms.BindingSource nastavnikBindingSource;
        private DnevnikDataSetTableAdapters.NastavnikTableAdapter nastavnikTableAdapter;
        private System.Windows.Forms.ComboBox cbUcenik;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.BindingSource ucenikBindingSource;
        private DnevnikDataSetTableAdapters.UcenikTableAdapter ucenikTableAdapter;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cbOcena;
        private System.Windows.Forms.Button btnPotvrdi;
        private System.Windows.Forms.ListBox lbOcene;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tbDatum;
    }
}