﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient; // dodato

namespace E_dnevnik
{
    public partial class PregledUcenikPredmet : Form
    {
        SqlConnection konekcija = new SqlConnection(Konekcija.KonString);
        public PregledUcenikPredmet()
        {
            InitializeComponent();
        }
        private void PregledUcenikPredmet_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dnevnikDataSet.Predmet' table. You can move, or remove it, as needed.
            this.predmetTableAdapter.Fill(this.dnevnikDataSet.Predmet);
            // TODO: This line of code loads data into the 'dnevnikDataSet.Ucenik' table. You can move, or remove it, as needed.
            this.ucenikTableAdapter.Fill(this.dnevnikDataSet.Ucenik);
            cbPredmet.SelectedIndex = -1;
            cbUcenik.SelectedIndex = -1;
        }
        private void btnPrikazi_Click(object sender, EventArgs e)
        {
            SqlCommand komanda = new SqlCommand();
            komanda.Connection = konekcija;
            komanda.CommandText = "select datum, ocena from OceneUcenika where sifraUcenik=" + (int.Parse)(cbUcenik.SelectedValue.ToString()) + " and IDPredmet=" + (int.Parse)(cbPredmet.SelectedValue.ToString()) + ";";
            SqlDataReader reader = null;
            try
            {
                konekcija.Open();
                reader = komanda.ExecuteReader();
                double prosek = 0;
                int brojac = 0;
                lbOcene.Items.Clear();
                lbOcene.Items.Add("Datum" + "\t\t" + "Ocene" + "\n");
                while (reader.Read())
                {
                    lbOcene.Items.Add(reader[0].ToString() + "\t" + reader[1].ToString() + "\n");
                    brojac++;
                    prosek += int.Parse(reader[1].ToString());
                }
                if (brojac == 0)
                {
                    lbOcene.Items.Add("\n\nUcenik nema ocene iz tog predmeta");
                }
                else
                {
                    lbOcene.Items.Add("\r\n\r\nProsek: " + "\t\t" + String.Format("{0:0.00}", prosek / brojac) + "\n");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Greska: " + ex.Message);
            }
            finally
            {
                konekcija.Close();
            }
        }

    }
}
