﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient; // dodato

namespace E_dnevnik
{
    public partial class PregledOcena : Form
    {
        SqlConnection konekcija = new SqlConnection(Konekcija.KonString);
        public PregledOcena()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dnevnikDataSet.Ucenik' table. You can move, or remove it, as needed.
            this.ucenikTableAdapter.Fill(this.dnevnikDataSet.Ucenik);
            cbUcenik.SelectedIndex = -1;
        }

        private void unosOcenaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UnosOcena nova = new UnosOcena();
            nova.ShowDialog();
        }

        private void izmenaOcenaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            IzmenaOcena nova = new IzmenaOcena();
            nova.ShowDialog();
        }

        private void pregledOcenaPoUcenikuIPredmetuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PregledUcenikPredmet nova = new PregledUcenikPredmet();
            nova.ShowDialog();
        }

        private void cbUcenik_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbUcenik.SelectedIndex != -1)
            {
                StringBuilder mojaKomanda = new StringBuilder();
                mojaKomanda.Append("SELECT predmet.Naziv, round(avg(cast(ocena as float)), 2) as [prosecna ocena] ");
                mojaKomanda.Append("FROM Predmet INNER JOIN OceneUcenika ON Predmet.IDPredmet = OceneUcenika.IDPredmet ");
                mojaKomanda.Append("WHERE OceneUcenika.sifraUcenik = " + int.Parse(cbUcenik.SelectedValue.ToString()));
                mojaKomanda.Append(" GROUP BY OceneUcenika.IDPredmet, predmet.naziv");

                SqlDataAdapter da = new SqlDataAdapter(mojaKomanda.ToString(), konekcija);
                DataSet ds = new DataSet();
                da.Fill(ds, "MojiPredmeti");
                DataTable dt = ds.Tables["MojiPredmeti"];
                dataGridView1.DataSource = dt;
            }
        }
    }
}
