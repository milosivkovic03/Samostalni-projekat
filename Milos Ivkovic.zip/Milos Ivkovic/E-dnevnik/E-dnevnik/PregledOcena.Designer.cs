﻿namespace E_dnevnik
{
    partial class PregledOcena
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.cbUcenik = new System.Windows.Forms.ComboBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.unosOcenaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.izmenaOcenaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pregledOcenaPoUcenikuIPredmetuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.dnevnikDataSet = new E_dnevnik.DnevnikDataSet();
            this.ucenikBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ucenikTableAdapter = new E_dnevnik.DnevnikDataSetTableAdapters.UcenikTableAdapter();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dnevnikDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ucenikBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(30, 88);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Ucenik";
            // 
            // cbUcenik
            // 
            this.cbUcenik.DataSource = this.ucenikBindingSource;
            this.cbUcenik.DisplayMember = "imePrezime";
            this.cbUcenik.FormattingEnabled = true;
            this.cbUcenik.Location = new System.Drawing.Point(104, 85);
            this.cbUcenik.Name = "cbUcenik";
            this.cbUcenik.Size = new System.Drawing.Size(191, 24);
            this.cbUcenik.TabIndex = 1;
            this.cbUcenik.ValueMember = "sifraUcenik";
            this.cbUcenik.SelectedIndexChanged += new System.EventHandler(this.cbUcenik_SelectedIndexChanged);
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pregledOcenaPoUcenikuIPredmetuToolStripMenuItem,
            this.unosOcenaToolStripMenuItem,
            this.izmenaOcenaToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(740, 28);
            this.menuStrip1.TabIndex = 6;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // unosOcenaToolStripMenuItem
            // 
            this.unosOcenaToolStripMenuItem.Name = "unosOcenaToolStripMenuItem";
            this.unosOcenaToolStripMenuItem.Size = new System.Drawing.Size(100, 24);
            this.unosOcenaToolStripMenuItem.Text = "Unos ocena";
            this.unosOcenaToolStripMenuItem.Click += new System.EventHandler(this.unosOcenaToolStripMenuItem_Click);
            // 
            // izmenaOcenaToolStripMenuItem
            // 
            this.izmenaOcenaToolStripMenuItem.Name = "izmenaOcenaToolStripMenuItem";
            this.izmenaOcenaToolStripMenuItem.Size = new System.Drawing.Size(179, 24);
            this.izmenaOcenaToolStripMenuItem.Text = "Izmena i brisanje ocena";
            this.izmenaOcenaToolStripMenuItem.Click += new System.EventHandler(this.izmenaOcenaToolStripMenuItem_Click);
            // 
            // pregledOcenaPoUcenikuIPredmetuToolStripMenuItem
            // 
            this.pregledOcenaPoUcenikuIPredmetuToolStripMenuItem.Name = "pregledOcenaPoUcenikuIPredmetuToolStripMenuItem";
            this.pregledOcenaPoUcenikuIPredmetuToolStripMenuItem.Size = new System.Drawing.Size(271, 24);
            this.pregledOcenaPoUcenikuIPredmetuToolStripMenuItem.Text = "Pregled ocena po uceniku i predmetu";
            this.pregledOcenaPoUcenikuIPredmetuToolStripMenuItem.Click += new System.EventHandler(this.pregledOcenaPoUcenikuIPredmetuToolStripMenuItem_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(33, 169);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(631, 285);
            this.dataGridView1.TabIndex = 7;
            // 
            // dnevnikDataSet
            // 
            this.dnevnikDataSet.DataSetName = "DnevnikDataSet";
            this.dnevnikDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // ucenikBindingSource
            // 
            this.ucenikBindingSource.DataMember = "Ucenik";
            this.ucenikBindingSource.DataSource = this.dnevnikDataSet;
            // 
            // ucenikTableAdapter
            // 
            this.ucenikTableAdapter.ClearBeforeFill = true;
            // 
            // PregledOcena
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(740, 523);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.cbUcenik);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "PregledOcena";
            this.Text = "E-dnevnik";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dnevnikDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ucenikBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbUcenik;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem unosOcenaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem izmenaOcenaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pregledOcenaPoUcenikuIPredmetuToolStripMenuItem;
        private System.Windows.Forms.DataGridView dataGridView1;
        private DnevnikDataSet dnevnikDataSet;
        private System.Windows.Forms.BindingSource ucenikBindingSource;
        private DnevnikDataSetTableAdapters.UcenikTableAdapter ucenikTableAdapter;
    }
}

