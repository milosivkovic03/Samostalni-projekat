﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient; // dodato

namespace E_dnevnik
{
    public partial class IzmenaOcena : Form
    {
        SqlConnection konekcija = new SqlConnection(Konekcija.KonString);
        public IzmenaOcena()
        {
            InitializeComponent();
        }
        private void IzmenaOcena_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dnevnikDataSet.Nastavnik' table. You can move, or remove it, as needed.
            this.nastavnikTableAdapter.Fill(this.dnevnikDataSet.Nastavnik);
            // TODO: This line of code loads data into the 'dnevnikDataSet.Ucenik' table. You can move, or remove it, as needed.
            this.ucenikTableAdapter.Fill(this.dnevnikDataSet.Ucenik);
        }
        private void cbNastavnik_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbNastavnik.SelectedIndex != -1)
            {
                string mojaKomanda = "SELECT Predmet.IDPredmet, Predmet.naziv FROM Predaje INNER JOIN Predmet ON Predaje.IDPredmet = Predmet.IDPredmet WHERE(Predaje.sifraNastavnika = " + int.Parse(cbNastavnik.SelectedValue.ToString()) + ")";

                SqlDataAdapter da = new SqlDataAdapter(mojaKomanda, konekcija);
                DataSet ds = new DataSet();
                da.Fill(ds, "MojiPredmeti");
                DataTable dt = ds.Tables["MojiPredmeti"];
                cbPredmet.DataSource = dt;
                cbPredmet.ValueMember = "IDPredmet";
                cbPredmet.DisplayMember = "naziv";
                
                cbPredmet.SelectedIndex = -1;
                cbPredmet.Visible = true;

                cbUcenik.SelectedIndex = -1;
                cbUcenik.Visible = true;
            }
        }

        private void cbUcenik_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbPredmet.SelectedIndex != -1)
            {
                string mojaKomanda = "SELECT OceneUcenika.datum, OceneUcenika.ocena FROM OceneUcenika INNER JOIN Predmet ON OceneUcenika.IDPredmet = Predmet.IDPredmet INNER JOIN Ucenik ON OceneUcenika.sifraUcenik = Ucenik.sifraUcenik WHERE(OceneUcenika.sifraUcenik = " + int.Parse(cbUcenik.SelectedValue.ToString()) +") AND(OceneUcenika.IDPredmet = "+ int.Parse(cbPredmet.SelectedValue.ToString()) + ")";

                SqlDataAdapter da = new SqlDataAdapter(mojaKomanda, konekcija);
                DataSet ds = new DataSet();
                da.Fill(ds, "MojiPredmeti");
                DataTable dt = ds.Tables["MojiPredmeti"];
                dataGridView1.DataSource = dt;              
            }
        }

        private void btnPotvrdi_Click(object sender, EventArgs e)
        {
            SqlCommand komanda = new SqlCommand();
            komanda.Connection = konekcija;
            string ocena = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            string datum = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            komanda.CommandText = "UPDATE OceneUcenika SET ocena = "+ int.Parse(ocena) +" WHERE(sifraUcenik = "+ int.Parse(cbUcenik.SelectedValue.ToString())+") AND(IDPredmet = "+ int.Parse(cbPredmet.SelectedValue.ToString()) + ") AND(datum = '"+ datum +"')";
            try
            {
                konekcija.Open();
                komanda.ExecuteNonQuery();
                MessageBox.Show("Ocena uspesno upisana");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Greska: " + ex.Message);
            }
            finally
            {
                konekcija.Close();
            }
        }

        private void brisiOcenuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SqlCommand komanda = new SqlCommand();
            komanda.Connection = konekcija;
            string datum = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
            komanda.CommandText = "DELETE OceneUcenika WHERE(sifraUcenik = " + int.Parse(cbUcenik.SelectedValue.ToString()) + ") AND(IDPredmet = " + int.Parse(cbPredmet.SelectedValue.ToString()) + ") AND(datum = '" + datum + "')";
            try
            {
                konekcija.Open();
                komanda.ExecuteNonQuery();
                MessageBox.Show("Ocena uspesno izbrisana");
                dataGridView1.Refresh();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Greska: " + ex.Message);
            }
            finally
            {
                konekcija.Close();
            }
        }
    }
}
