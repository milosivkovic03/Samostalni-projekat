﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient; // dodato


namespace E_dnevnik
{
    public partial class UnosOcena : Form
    {
        SqlConnection konekcija = new SqlConnection(Konekcija.KonString);
        public UnosOcena()
        {
            InitializeComponent();
        }

        private void UnosOcena_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dnevnikDataSet.Ucenik' table. You can move, or remove it, as needed.
            this.ucenikTableAdapter.Fill(this.dnevnikDataSet.Ucenik);
            // TODO: This line of code loads data into the 'dnevnikDataSet.Nastavnik' table. You can move, or remove it, as needed.
            this.nastavnikTableAdapter.Fill(this.dnevnikDataSet.Nastavnik);

        }
        private void cbNastavnik_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbNastavnik.SelectedIndex != -1)
            {
                string mojaKomanda = "SELECT Predmet.IDPredmet, Predmet.naziv FROM Predaje INNER JOIN Predmet ON Predaje.IDPredmet = Predmet.IDPredmet WHERE(Predaje.sifraNastavnika = " + int.Parse(cbNastavnik.SelectedValue.ToString()) + ")";

                SqlDataAdapter da = new SqlDataAdapter(mojaKomanda, konekcija);
                DataSet ds = new DataSet();
                da.Fill(ds, "MojiPredmeti");
                DataTable dt = ds.Tables["MojiPredmeti"];
                cbPredmet.DataSource = dt;
                cbPredmet.ValueMember = "IDPredmet";
                cbPredmet.DisplayMember = "naziv";
            }
        }

        private void btnPotvrdi_Click(object sender, EventArgs e)
        {
            SqlCommand komanda = new SqlCommand();
            komanda.Connection = konekcija;
            komanda.CommandText = "INSERT INTO OceneUcenika (sifraUcenik, IDPredmet, datum, ocena) VALUES(" + int.Parse(cbUcenik.SelectedValue.ToString()) + ", " + int.Parse(cbPredmet.SelectedValue.ToString()) + ", N'" + tbDatum.Text + "', " + int.Parse(cbOcena.Text.ToString()) + ")";
            SqlDataReader reader = null;
            try
            {
                konekcija.Open();
                komanda.ExecuteNonQuery();
                komanda.CommandText = "select datum, ocena from OceneUcenika where sifraUcenik=" + (int.Parse)(cbUcenik.SelectedValue.ToString()) + " and IDPredmet=" + (int.Parse)(cbPredmet.SelectedValue.ToString()) + ";";
                reader = komanda.ExecuteReader();
                double prosek = 0;
                int brojac = 0;
                lbOcene.Items.Clear();
                lbOcene.Items.Add("Datum" + "\t\t" + "Ocene" + "\n");
                while (reader.Read())
                {
                    lbOcene.Items.Add(reader[0].ToString() + "\t" + reader[1].ToString() + "\n");
                    brojac++;
                    prosek += int.Parse(reader[1].ToString());
                }
                if (brojac == 0)
                {
                    lbOcene.Items.Add("\n\nUcenik nema ocene iz tog predmeta");
                }
                else
                {
                    lbOcene.Items.Add("\n\nProsek: " + "\t\t" + String.Format("{0:0.00}", prosek/brojac) + "\n");
                }
                MessageBox.Show("Ocena uspesno upisana");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Greska: " + ex.Message);
            }
            finally
            {
                konekcija.Close();
            }
        }
    }
}
