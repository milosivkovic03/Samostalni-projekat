﻿namespace E_dnevnik
{
    partial class IzmenaOcena
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnPotvrdi = new System.Windows.Forms.Button();
            this.cbUcenik = new System.Windows.Forms.ComboBox();
            this.ucenikBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dnevnikDataSet = new E_dnevnik.DnevnikDataSet();
            this.label3 = new System.Windows.Forms.Label();
            this.cbPredmet = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cbNastavnik = new System.Windows.Forms.ComboBox();
            this.nastavnikBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.brisiOcenuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ucenikTableAdapter = new E_dnevnik.DnevnikDataSetTableAdapters.UcenikTableAdapter();
            this.nastavnikTableAdapter = new E_dnevnik.DnevnikDataSetTableAdapters.NastavnikTableAdapter();
            this.oceneUcenikaTableAdapter1 = new E_dnevnik.DnevnikDataSetTableAdapters.OceneUcenikaTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.ucenikBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dnevnikDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nastavnikBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnPotvrdi
            // 
            this.btnPotvrdi.Location = new System.Drawing.Point(574, 248);
            this.btnPotvrdi.Name = "btnPotvrdi";
            this.btnPotvrdi.Size = new System.Drawing.Size(75, 30);
            this.btnPotvrdi.TabIndex = 24;
            this.btnPotvrdi.Text = "Potvrdi";
            this.btnPotvrdi.UseVisualStyleBackColor = true;
            this.btnPotvrdi.Click += new System.EventHandler(this.btnPotvrdi_Click);
            // 
            // cbUcenik
            // 
            this.cbUcenik.DataSource = this.ucenikBindingSource;
            this.cbUcenik.DisplayMember = "imePrezime";
            this.cbUcenik.FormattingEnabled = true;
            this.cbUcenik.Location = new System.Drawing.Point(713, 52);
            this.cbUcenik.Name = "cbUcenik";
            this.cbUcenik.Size = new System.Drawing.Size(191, 24);
            this.cbUcenik.TabIndex = 21;
            this.cbUcenik.ValueMember = "sifraUcenik";
            this.cbUcenik.Visible = false;
            this.cbUcenik.SelectedIndexChanged += new System.EventHandler(this.cbUcenik_SelectedIndexChanged);
            // 
            // ucenikBindingSource
            // 
            this.ucenikBindingSource.DataMember = "Ucenik";
            this.ucenikBindingSource.DataSource = this.dnevnikDataSet;
            // 
            // dnevnikDataSet
            // 
            this.dnevnikDataSet.DataSetName = "DnevnikDataSet";
            this.dnevnikDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(639, 55);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(51, 17);
            this.label3.TabIndex = 20;
            this.label3.Text = "Ucenik";
            // 
            // cbPredmet
            // 
            this.cbPredmet.DisplayMember = "naziv";
            this.cbPredmet.FormattingEnabled = true;
            this.cbPredmet.Location = new System.Drawing.Point(415, 49);
            this.cbPredmet.Name = "cbPredmet";
            this.cbPredmet.Size = new System.Drawing.Size(191, 24);
            this.cbPredmet.TabIndex = 19;
            this.cbPredmet.ValueMember = "IDPredmet";
            this.cbPredmet.Visible = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(348, 52);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 17);
            this.label2.TabIndex = 18;
            this.label2.Text = "Predmet";
            // 
            // cbNastavnik
            // 
            this.cbNastavnik.DataSource = this.nastavnikBindingSource;
            this.cbNastavnik.DisplayMember = "imePrezime";
            this.cbNastavnik.FormattingEnabled = true;
            this.cbNastavnik.Location = new System.Drawing.Point(119, 52);
            this.cbNastavnik.Name = "cbNastavnik";
            this.cbNastavnik.Size = new System.Drawing.Size(191, 24);
            this.cbNastavnik.TabIndex = 17;
            this.cbNastavnik.ValueMember = "sifraNastavnika";
            this.cbNastavnik.SelectedIndexChanged += new System.EventHandler(this.cbNastavnik_SelectedIndexChanged);
            // 
            // nastavnikBindingSource
            // 
            this.nastavnikBindingSource.DataMember = "Nastavnik";
            this.nastavnikBindingSource.DataSource = this.dnevnikDataSet;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(33, 55);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 17);
            this.label1.TabIndex = 16;
            this.label1.Text = "Nastavnik";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.ContextMenuStrip = this.contextMenuStrip1;
            this.dataGridView1.Location = new System.Drawing.Point(36, 141);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(441, 264);
            this.dataGridView1.TabIndex = 25;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.brisiOcenuToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(151, 28);
            // 
            // brisiOcenuToolStripMenuItem
            // 
            this.brisiOcenuToolStripMenuItem.Name = "brisiOcenuToolStripMenuItem";
            this.brisiOcenuToolStripMenuItem.Size = new System.Drawing.Size(150, 24);
            this.brisiOcenuToolStripMenuItem.Text = "Brisi ocenu";
            this.brisiOcenuToolStripMenuItem.Click += new System.EventHandler(this.brisiOcenuToolStripMenuItem_Click);
            // 
            // ucenikTableAdapter
            // 
            this.ucenikTableAdapter.ClearBeforeFill = true;
            // 
            // nastavnikTableAdapter
            // 
            this.nastavnikTableAdapter.ClearBeforeFill = true;
            // 
            // oceneUcenikaTableAdapter1
            // 
            this.oceneUcenikaTableAdapter1.ClearBeforeFill = true;
            // 
            // IzmenaOcena
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(958, 444);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.btnPotvrdi);
            this.Controls.Add(this.cbUcenik);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cbPredmet);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cbNastavnik);
            this.Controls.Add(this.label1);
            this.Name = "IzmenaOcena";
            this.Text = "Izmena Ocena";
            this.Load += new System.EventHandler(this.IzmenaOcena_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ucenikBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dnevnikDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nastavnikBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnPotvrdi;
        private System.Windows.Forms.ComboBox cbUcenik;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cbPredmet;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cbNastavnik;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private DnevnikDataSet dnevnikDataSet;
        private System.Windows.Forms.BindingSource ucenikBindingSource;
        private DnevnikDataSetTableAdapters.UcenikTableAdapter ucenikTableAdapter;
        private System.Windows.Forms.BindingSource nastavnikBindingSource;
        private DnevnikDataSetTableAdapters.NastavnikTableAdapter nastavnikTableAdapter;
        private DnevnikDataSetTableAdapters.OceneUcenikaTableAdapter oceneUcenikaTableAdapter1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem brisiOcenuToolStripMenuItem;
    }
}